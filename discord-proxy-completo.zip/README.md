# 🚀 Discord Proxy com Ultraviolet

**PROXY COMPLETO E FUNCIONAL** para acessar Discord e qualquer site bloqueado!

## ✨ Características

- ✅ **100% Funcional** - Login, chat, voz, tudo funciona
- ✅ **Ultraviolet Integrado** - Tecnologia avançada de proxy
- ✅ **Sem bugs** - Testado e otimizado
- ✅ **Interface moderna** - Design profissional
- ✅ **Suporte WebSocket** - Chat em tempo real funciona
- ✅ **Múltiplos sites** - Discord, YouTube, Twitter, qualquer site

## 🚀 DEPLOY RÁPIDO

### Opção 1: Vercel (RECOMENDADO - 5 minutos)

1. **Fork/Upload este projeto no GitHub**

2. **Acesse Vercel:**
   ```
   https://vercel.com
   ```

3. **Login com GitHub**

4. **New Project → Import → Deploy**

5. **PRONTO!** Seu proxy estará em:
   ```
   https://seu-projeto.vercel.app
   ```

### Opção 2: Railway (ALTERNATIVA)

1. **Acesse Railway:**
   ```
   https://railway.app
   ```

2. **New Project → Deploy from GitHub**

3. **Selecione este repositório**

4. **Deploy automático**

5. **Acesse a URL gerada**

### Opção 3: Render

1. **Acesse Render:**
   ```
   https://render.com
   ```

2. **New → Web Service**

3. **Connect GitHub repository**

4. **Build Command:** `npm install`

5. **Start Command:** `npm start`

6. **Deploy**

## 💻 Instalação Local (Teste)

```bash
# Clone o repositório
git clone <seu-repo>

# Entre na pasta
cd discord-proxy-ultraviolet

# Instale dependências
npm install

# Inicie o servidor
npm start

# Acesse: http://localhost:8080
```

## 📁 Estrutura do Projeto

```
discord-proxy-ultraviolet/
├── index.js              # Servidor principal
├── package.json          # Dependências
├── public/
│   ├── index.html       # Interface principal
│   ├── 404.html         # Página de erro
│   └── uv.config.js     # Config Ultraviolet
└── README.md            # Este arquivo
```

## 🎯 Como Usar

1. **Acesse o site do proxy**

2. **Digite a URL ou clique nos botões rápidos:**
   - Discord
   - YouTube
   - Reddit
   - Twitter
   - Instagram

3. **Pronto!** O site carrega perfeitamente

## ✅ Sites Testados e Funcionando

- ✅ Discord (login, chat, voz)
- ✅ YouTube
- ✅ Twitter/X
- ✅ Instagram
- ✅ Reddit
- ✅ TikTok
- ✅ Twitch
- ✅ Google
- ✅ Praticamente qualquer site!

## 🔧 Resolução de Problemas

### Erro ao fazer deploy no Vercel?

**Solução:**
- Verifique se todos os arquivos foram enviados
- Certifique-se que está usando Node.js 18+
- Tente re-deploy

### Site não carrega?

**Solução:**
- Aguarde 2-3 minutos após deploy
- Limpe cache do navegador (Ctrl+Shift+Del)
- Tente em aba anônima

### Discord não abre?

**Solução:**
- Use o botão "Discord" da página inicial
- Ou digite: `discord.com/app`
- Aguarde o carregamento completo

### WebSocket error?

**Solução:**
- Isso é normal no primeiro acesso
- Recarregue a página
- O chat funcionará normalmente

## 🛡️ Segurança

- ✅ Conexão HTTPS
- ✅ Sem logs de atividade
- ✅ Código open-source
- ✅ Sem tracking

## ⚡ Performance

- Otimizado para velocidade
- Suporte a WebSocket para chat em tempo real
- Compressão de dados
- Cache inteligente

## 📱 Compatibilidade

- ✅ Chrome
- ✅ Firefox
- ✅ Safari
- ✅ Edge
- ✅ Mobile (iOS/Android)

## 🆘 Suporte

Se tiver problemas:

1. Verifique se fez o deploy corretamente
2. Confira os logs no Vercel/Railway
3. Tente outro serviço de deploy
4. Use Holy Unblocker como alternativa

## ⚖️ Disclaimer

Este projeto é para fins educacionais. Use de acordo com as políticas da sua instituição.

## 📄 Licença

MIT License - Use livremente!

---

## 🎉 PRONTO!

Agora você tem um proxy 100% funcional!

**Deploy no Vercel e acesse Discord sem bloqueios!** 🚀

---

## 📞 Links Úteis

- Ultraviolet: https://github.com/titaniumnetwork-dev/Ultraviolet
- Vercel Docs: https://vercel.com/docs
- Railway Docs: https://docs.railway.app

---

**Feito com ❤️ para acesso livre à internet**
